import pytest

from pyrecore.core.datalink import DataLink
from pyrecore.core.exception import PyRECoreError
from pyrecore.core.packet import Header, Request
from pyrecore.core.remote_protocol import RemoteProtocol


class MockReadableDataLink(DataLink):
    def __init__(self, data: bytes):
        self._data = data
        self._offset = 0

    def read_sync(self, size: int) -> bytes:
        k = self._offset + size
        b = self._data[self._offset : k]
        self._offset = k
        return b

    def write_sync(self, data: bytes):
        pass


def test_read_success():
    link = MockReadableDataLink(b"\xFC\x04\xCC\xDD\xEE\xFF\xEC")
    prot = RemoteProtocol(link, "little")
    actual = prot.read()

    assert Header.ACK == actual.header
    assert b"\xCC\xDD\xEE\xFF" == actual.payload


def test_read_failure():
    link = MockReadableDataLink(b"\xFC\x04\xCC\xDD\xEE\xFF\xAB")
    prot = RemoteProtocol(link, "little")

    with pytest.raises(PyRECoreError) as e:
        _ = prot.read()

    assert str(e.value) == "INVALID_CRC"


class MockWritableDataLink(DataLink):
    def __init__(self):
        self._data = b""

    def read_sync(self, size: int) -> bytes:
        pass

    def write_sync(self, data: bytes):
        self._data += data


def test_write_success():
    link = MockWritableDataLink()
    prot = RemoteProtocol(link, "little")
    prot.write(Request(0x3142, b"\xCC\xDD\xEE\xFF"))

    assert b"\x3C\x04\x42\x31\xCC\xDD\xEE\xFF\x0A" == link._data
