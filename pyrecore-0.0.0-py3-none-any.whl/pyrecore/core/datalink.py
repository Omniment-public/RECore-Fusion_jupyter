# RECore-PyRECore --- A Python library for control of RECore
#
# Copyright (c) 2021 Omniment, Inc.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from abc import ABCMeta, abstractmethod

import serial


class DataLink(metaclass=ABCMeta):
    """An abstract class for the data link layer."""

    def close(self):
        pass

    @abstractmethod
    def read_sync(self, size: int) -> bytes:
        pass

    @abstractmethod
    def write_sync(self, data: bytes):
        pass


class SerialDataLink(DataLink):
    def __init__(self, conn: serial.Serial):
        self._conn = conn

    def __enter__(self):
        return self

    def __exit__(self, ex_type, ex_value, trace):
        self.close()

    def close(self):
        self._conn.close()

    def read_sync(self, size: int) -> bytes:
        return self._conn.read(size)

    def write_sync(self, data: bytes):
        self._conn.write(data)
        self._conn.flush()
