# RECore-PyRECore --- A Python library for control of RECore
#
# Copyright (c) 2021 Omniment, Inc.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from enum import IntEnum

PAYLOAD_MAX_LENGTH = 255


class Header(IntEnum):
    REQ = 0x3C  # Requests
    ACK = 0xFC  # Successful responses
    NACK = 0x3F  # Failed responses


class Error(IntEnum):
    OK = 0x00
    INVALID_HEADER = 0x01
    INVALID_OPCODE = 0x02
    INVALID_CRC = 0x03
    TOO_LARGE_DATA = 0x04


class Request:
    def __init__(self, opcode: int, payload: bytes):
        if not isinstance(opcode, int):
            raise TypeError("opcode")
        if not isinstance(payload, bytes):
            raise TypeError("payload")
        if not (opcode >= 0 and opcode <= 0xFFFF):
            raise ValueError("opcode out of range")
        if not (len(payload) <= PAYLOAD_MAX_LENGTH):
            raise ValueError("too large payload")

        self.header = Header.REQ
        self.opcode = opcode
        self.payload = payload

    def __repr__(self) -> str:
        return "Request(%s, %#06x, %s)" % (self.header.name, self.opcode, self.payload)


class Response:
    def __init__(self, header: Header, payload: bytes):
        if not isinstance(header, Header):
            raise TypeError("header")
        if not isinstance(payload, bytes):
            raise TypeError("payload")
        if not (len(payload) <= PAYLOAD_MAX_LENGTH):
            raise ValueError("too large payload")

        self.header = header
        self.payload = payload

    def __repr__(self) -> str:
        return "Response(%s, %s)" % (self.header.name, self.payload)
