#!/usr/bin/env python3
# RECore-PyRECore --- A Python library for control of RECore
#
# Copyright (c) 2021 Omniment, Inc.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import argparse

import yaml
from jinja2 import Environment, FileSystemLoader


def sizeof(t):
    if t == "int8_t" or t == "uint8_t":
        return 1
    elif t == "int16_t" or t == "uint16_t":
        return 2
    elif t == "int32_t" or t == "uint32_t":
        return 4
    elif t == "float":
        return 4
    else:
        return 1


def signed(t):
    return t == "int8_t" or t == "int16_t" or t == "int32_t"


def struct_format(t):
    if t == "int8_t":
        return "b"
    elif t == "uint8_t":
        return "B"
    elif t == "int16_t":
        return "h"
    elif t == "uint16_t":
        return "H"
    elif t == "int32_t":
        return "i"
    elif t == "uint32_t":
        return "I"
    elif t == "float":
        return "f"
    else:
        raise ValueError("Unknown type: %s" % t)


def codegen(config_path, input_path, output_path):
    env = Environment(loader=FileSystemLoader(".", encoding="utf_8_sig"))

    template = env.get_template(input_path)

    with open(config_path, encoding="utf_8_sig") as fin:
        config = yaml.safe_load(fin)

    for i, operation in enumerate(config["operations"]):
        operation["opcode"] = i + 1

        offset = 0
        if "parameters" in operation:
            for par in operation["parameters"]:
                size = sizeof(par["type"]["arduino"])
                # memory alignment
                if offset % size == 0:
                    padding = 0
                else:
                    padding = size - (offset % size)
                par["type"]["size"] = size
                par["type"]["offset"] = offset + padding
                par["type"]["format"] = "".join(["x" for _ in range(padding)]) + struct_format(par["type"]["arduino"])
                offset += size + padding

        if "return_type" in operation:
            operation["return_type"]["size"] = sizeof(operation["return_type"]["arduino"])
            operation["return_type"]["signed"] = signed(operation["return_type"]["arduino"])
            operation["return_type"]["format"] = struct_format(operation["return_type"]["arduino"])

    render = template.render(config)

    # Output
    with open(output_path, "w", encoding="utf_8_sig") as fout:
        fout.write(render)


def main():
    parser = argparse.ArgumentParser(description="Code-generation for PyRECore")
    parser.add_argument("config_path", metavar="CONFIG_PATH", type=str)
    parser.add_argument("input_path", metavar="INPUT_PATH", type=str)
    parser.add_argument("output_path", metavar="OUTPUT_PATH", type=str)

    args = parser.parse_args()
    codegen(args.config_path, args.input_path, args.output_path)


if __name__ == "__main__":
    main()
